#pragma once

#define HTTP_SERVER "114.29.238.24"
#define HTTP_PORT 80

#define TFTP_SERVER "114.29.238.24"
